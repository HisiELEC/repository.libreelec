export NODEJS_HOME=/storage/.kodi/addons/service.nodejs
